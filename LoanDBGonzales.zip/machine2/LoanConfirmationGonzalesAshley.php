<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: LoginGonzalesAshley.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Confirmation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>ASHLEY GWAPO COOPERATIVE INCORPORATED</h1>
        <p>Forever Gwapo si Ashley St., Tokyo City</p>
        <p>Telephone #: 143-4456</p>

        <h2>LOAN CONFIRMATION</h2>
        <p>Your loan has been confirmed. Thank you for choosing Ashley Gwapo Cooperative Incorporated.</p>

        <form method="POST" action="LoginGonzalesAshley.php">
            <input type="submit" value="Back to Login">
        </form>
    </div>
</body>
</html>