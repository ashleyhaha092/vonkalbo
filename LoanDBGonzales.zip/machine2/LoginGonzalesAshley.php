<?php
session_start();
$error_message = "";
$show_loan_button = false;

// Database connection
$db = new mysqli('localhost', 'root', '', 'ashley_cooperative');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["accept"])) {
    $username = $_POST["username"] ?? "";
    $password = $_POST["password"] ?? "";

    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['user_id'] = $result->fetch_assoc()['id'];
        $show_loan_button = true;
    } else {
        $error_message = "Invalid username or password";
    }
}

if (isset($_POST["loan_page"])) {
    header("Location: LoanAmountGonzalesAshley.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>ASHLEY POGI COOPERATIVE INCORPORATED</h1>
        <p>Forever Gwapo si Ashley St., Tokyo City</p>
        <p>Telephone #: 143-4456</p>

        <h2>USER NAME & PASSWORD ENTRY:</h2>
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" maxlength="5" required><br><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" maxlength="5" required><br><br>
            <input type="submit" name="accept" value="Accept">
        </form>

        <?php if (!empty($error_message)): ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <?php if ($show_loan_button): ?>
            <form method="POST" action="">
                <input type="submit" name="loan_page" value="Loan Page" class="loan-button">
            </form>
        <?php endif; ?>
    </div>
</body>
</html>