<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Amount</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>ASHLEY GWAPO COOPERATIVE INCORPORATED</h1>
        <p>Forever Gwapo si Ashley St., Tokyo City</p>
        <p>Telephone #: 143-4456</p>

        <h2>LOAN AMOUNT</h2>
        <form method="POST" action="LoanInformationGonzalesAshley.php">
            <table>
                <tr>
                    <th>Select Loan Amount</th>
                    <th>Amount</th>
                </tr>
                <tr>
                    <td><input type="radio" name="loan_amount" value="5000" required></td>
                    <td>₱5,000.00</td>
                </tr>
                <tr>
                    <td><input type="radio" name="loan_amount" value="10000"></td>
                    <td>₱10,000.00</td>
                </tr>
                <tr>
                    <td><input type="radio" name="loan_amount" value="15000"></td>
                    <td>₱15,000.00</td>
                </tr>
                <tr>
                    <td><input type="radio" name="loan_amount" value="20000"></td>
                    <td>₱20,000.00</td>
                </tr>
                <tr>
                    <td><input type="radio" name="loan_amount" value="25000"></td>
                    <td>₱25,000.00</td>
                </tr>
            </table>

            <h3>Terms of Payment</h3>
            <table>
                <tr>
                    <th>Term</th>
                </tr>
                <tr>
                    <td><input type="radio" name="terms" value="6" required> 6 months</td>
                </tr>
                <tr>
                    <td><input type="radio" name="terms" value="12"> 12 months</td>
                </tr>
                <tr>
                    <td><input type="radio" name="terms" value="24"> 24 months</td>
                </tr>
            </table>

            <label>Cooperative Officer:</label>
            <input type="checkbox" name="officer" value="yes"><br><br>

            <input type="submit" value="Confirm Loan">
            <input type="reset" value="Clear All">