<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: LoginGonzalesAshley.php");
    exit();
}

$db = new mysqli('localhost', 'root', '', 'ashley_cooperative');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan_amount = $_POST["loan_amount"];
    $terms = $_POST["terms"];
    $officer = isset($_POST["officer"]) ? "Yes" : "No";
    $user_id = $_SESSION['user_id'];

    $interest_rate = $officer === "Yes" ? 0.05 : 0.10;
    $interest = $loan_amount * $interest_rate;
    $total_amount = $loan_amount + $interest;
    $monthly_dues = $total_amount / $terms;

    $stmt = $db->prepare("INSERT INTO loans (user_id, amount, terms, interest_rate, total_amount, monthly_dues, is_officer) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ididdds", $user_id, $loan_amount, $terms, $interest_rate, $total_amount, $monthly_dues, $officer);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Information</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>ASHLEY GWAPO COOPERATIVE INCORPORATED</h1>
        <p>Forever Gwapo si Ashley St., Tokyo City</p>
        <p>Telephone #: 143-4456</p>

        <h2>LOAN INFORMATION</h2>
        <table>
            <tr>
                <th>Loan Amount</th>
                <th>Interest Rate</th>
                <th>Total Amount</th>
                <th>Monthly Dues</th>
                <th>Terms of Payment</th>
                <th>Cooperative Officer</th>
            </tr>
            <tr>
                <td>₱<?php echo number_format($loan_amount, 2); ?></td>
                <td><?php echo ($interest_rate * 100); ?>%</td>
                <td>₱<?php echo number_format($total_amount, 2); ?></td>
                <td>₱<?php echo number_format($monthly_dues, 2); ?></td>
                <td><?php echo $terms; ?> months</td>
                <td><?php echo $officer; ?></td>
            </tr>
        </table>

        <form method="POST" action="LoanConfirmationGonzalesAshley.php">
            <input type="submit" value="Submit">
            <input type="button" value="Back" onclick="window.location.href='LoanAmountGonzalesAshley.php'">
        </form>
    </div>
</body>
</html>