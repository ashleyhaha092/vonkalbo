<?php include 'header.php'; ?>

<h3>View Guests</h3>
<form method="get">
    Sort by: 
    <select name="sort">
        <option value="name">Name</option>
        <option value="email">Email</option>
        <option value="date">Date Registered</option>
    </select>
    <input type="submit" value="Go">
    
    Search here: <input type="text" name="search" placeholder="Enter search term">
    <input type="submit" value="Search">
</form>

<h4>GUEST INFORMATION</h4>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Date Registered</th>
    </tr>
    
<?php
$conn = new mysqli('localhost', 'root', '', 'guest_registration');

// Build query based on sorting and searching
$sql = "SELECT * FROM guests";
$where = [];

if (!empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $where[] = "(first_name LIKE '$search%' OR last_name LIKE '$search%' OR email LIKE '%$search%')";
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

if (!empty($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'name': $sql .= " ORDER BY last_name, first_name"; break;
        case 'email': $sql .= " ORDER BY email"; break;
        case 'date': $sql .= " ORDER BY date_registered"; break;
    }
}

$result = $conn->query($sql);
$total = $result->num_rows;

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['last_name']}, {$row['first_name']}</td>
        <td>{$row['email']}</td>
        <td>{$row['date_registered']}</td>
    </tr>";
}
?>
</table>

<p>Total Records: <?php echo $total; ?></p>

<?php include 'footer.php'; ?>