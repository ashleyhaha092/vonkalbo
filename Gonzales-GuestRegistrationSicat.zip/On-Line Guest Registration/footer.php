<footer style="margin-top: 20px; border-top: 1px solid #ccc; padding-top: 10px;">
            Prepared by: Ashley Gonzales
        </footer>
    </div>
</body>
</html>