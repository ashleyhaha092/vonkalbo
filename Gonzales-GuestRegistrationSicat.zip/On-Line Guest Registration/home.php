<?php include 'header.php'; ?>

<h3>Login</h3>
<form action="home.php" method="post">
    Email Address: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <input type="submit" name="login" value="Login">
</form>

<?php
if (isset($_POST['login'])) {
   
    session_start();
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['first_name'] = "Richard"; 
    
    echo "<p>Welcome!... {$_SESSION['first_name']}</p>";
    echo "<a href='home.php'>Continue</a>";
}
?>

<?php include 'footer.php'; ?>