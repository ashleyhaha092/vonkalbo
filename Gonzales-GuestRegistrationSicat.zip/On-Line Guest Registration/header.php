<!DOCTYPE html>
<html>
<head>
    <title>ON-LINE GUEST REGISTRATION</title>
    <style>
        body { 
        font-family: Arial, sans-serif; 
        margin: 20px; 
        }
        nav { 
            background: #f0f0f0; 
            padding: 10px; 
            margin-bottom: 20px; 
        }
        nav a { margin-right: 15px; 
            text-decoration: none; 
        }
        .container { 
            max-width: 800px; 
            margin: 0 auto; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>ON-LINE GUEST REGISTRATION</h2>
        <nav>
            <a href="home.php">Home</a>
            <a href="register.php">Register</a>
            <a href="view.php">View</a>
            <a href="update.php">Update</a>
            <a href="delete.php">Delete</a>
            <a href="search.php">Search</a>
        </nav>