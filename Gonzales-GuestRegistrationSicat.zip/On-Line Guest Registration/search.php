<?php include 'header.php'; ?>

<h3>Search</h3>
<form method="get">
    User ID: <input type="number" name="id" required>
    <input type="submit" value="Search">
</form>

<?php
if (!empty($_GET['id'])) {
    $conn = new mysqli('localhost', 'root', '', 'guest_registration');
    $id = $conn->real_escape_string($_GET['id']);
    $result = $conn->query("SELECT * FROM guests WHERE id = $id");
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>
        <p>User ID: <?php echo $row['id']; ?></p>
        <p>Name: <?php echo $row['last_name'], ', ', $row['first_name']; ?></p>
        <p>Email Address: <?php echo $row['email']; ?></p>
        <p>Date registered: <?php echo $row['date_registered']; ?></p>
        <?php
    } else {
        echo "<p>No user found with ID {$_GET['id']}</p>";
    }
}
?>

<?php include 'footer.php'; ?>