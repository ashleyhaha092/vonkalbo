<?php include 'header.php'; ?>

<h3>Register</h3>
<form action="register.php" method="post">
    First Name: <input type="text" name="first_name" required><br><br>
    Last Name: <input type="text" name="last_name" required><br><br>
    Email Address: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <input type="submit" name="register" value="Register">
</form>

<?php
if (isset($_POST['register'])) {
    // Connect to database
    $conn = new mysqli('localhost', 'root', '', 'guest_registration');
    
    // Insert new guest
    $stmt = $conn->prepare("INSERT INTO guests (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['password']);
    $stmt->execute();
    
    echo "<p>Thank you...</p>";
    echo "<p>You are now registered...</p>";
    echo "<a href='home.php'>Login</a>";
    
    $stmt->close();
    $conn->close();
}
?>

<?php include 'footer.php'; ?>