<?php include 'header.php'; ?>

<h3>Delete Record</h3>
<form method="get">
    User ID: <input type="number" name="id" required>
    <input type="submit" value="Search">
</form>

<?php
if (!empty($_GET['id'])) {
    $conn = new mysqli('localhost', 'root', '', 'guest_registration');
    $id = $conn->real_escape_string($_GET['id']);
    $result = $conn->query("SELECT * FROM guests WHERE id = $id");
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>
        <form action="delete.php" method="post">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            User ID: <?php echo $row['id']; ?><br>
            Name: <?php echo $row['last_name'], ', ', $row['first_name']; ?><br>
            Email Address: <?php echo $row['email']; ?><br>
            Date registered: <?php echo $row['date_registered']; ?><br><br>
            
            <p>Deleting Record... Are you sure?</p>
            <input type="submit" name="delete" value="YES">
            <a href="delete.php">NO</a>
        </form>
        <?php
    } else {
        echo "<p>No user found with ID {$_GET['id']}</p>";
    }
}

if (isset($_POST['delete'])) {
    $conn = new mysqli('localhost', 'root', '', 'guest_registration');
    $stmt = $conn->prepare("DELETE FROM guests WHERE id=?");
    $stmt->bind_param("i", $_POST['id']);
    $stmt->execute();
    
    echo "<p>Record has been deleted...</p>";
    $stmt->close();
    $conn->close();
}
?>

<?php include 'footer.php'; ?>